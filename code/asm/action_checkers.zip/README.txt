--------------------------
WELCOME to ACTION CHECKERS
--------------------------

Thank you for choosing ACTION CHECKERS. LeMonds Software
hopes that you will enjoy playing the game.

------------------------
WHAT is ACTION CHECKERS?
------------------------

The ACTION CHECKERS game is similar to the game of checkers,
and is played on a board that is similar to a checkers board.
However, that's where the similarities end! Think that you
can get to the other side of the board? Just wait and see
what happens!

The object of the game is to move one of your pieces to the
other side of the board. That's right, just one piece! It
sounds like an easy thing to do, but the going will be rough.
The board is a minefield, and if you move or jump onto a mine,
there goes another one of your pieces. Occasionally pieces are
arrested and put in jail. When trial occurs, the judge is not
usually very lenient. Then, there are the electric fences,
which aren't too good for your pieces either. A player can
also win when his or her opponent runs out of pieces.

You can play the computer (with an easy or harder level of
play), or a human opponent. The board layout and colors, and
the various "events" are all easy to customize.

Good luck. You'll need it!

-----------------------------------------------
SYSTEM REQUIREMENTS for RUNNING ACTION CHECKERS
-----------------------------------------------

	o) WINDOWS 95 Operating System
	o) 2 MB of free space on your hard drive.

----------------------------------
INSTALLING ACTION CHECKERS is EASY
----------------------------------

The procedure for installing ACTION CHECKERS on your computer
is very straightforward. A setup program is not provided since
manual installation is so simple. In addition, if a setup
program were to be used, then the size of the ZIP file
obtained from an Internet download would be twice as large
as it currently is. Accordingly, the Internet download
proceeds much faster without the setup program.

----------------------
ACTION CHECKERS FOLDER
----------------------

The installation instructions assume that ACTION CHECKERS is
to be installed in the following folder:

	C:\Program Files\Action Checkers

However, you are free to install the program in any new folder
of your choice.

------------------------------------------
INSTALLING ACTION CHECKERS from a ZIP FILE
OBTAINED from an INTERNET DOWNLOAD
------------------------------------------

1) Unzip (decompress) the ZIP file "ActChkrs.zip" using any
   standard file unzipping software (available on the Internet).

   Unzip the ACTION CHECKERS files into the folder
	C:\Program Files\Action Checkers

   All the ACTION CHECKERS files should be in one folder.

2) Check to see that the ACTION CHECKERS files which are in your
   new folder "C:\Program Files\Action Checkers" match those
   shown in the "Packing List" below. In order for the program
   to work properly, all of the files shown in the packing list
   must be located in the same folder.

   ACTION CHECKERS is essentially installed at this point, and
   is ready to run. However, you probably will want to create a
   shortcut to the ACTION CHECKERS executable on the Start menu
   or on the Desktop, as explained in the next step.

3) You may create a short-cut to the ACTION CHECKERS executable
   in the Windows95 Start menu, enabling you to launch ACTION
   CHECKERS from the Start menu when you wish to use the program.

   One way to do this is as follows: Open the folder
	C:\Windows\Start Menu\Programs
   Then, open the folder
	C:\Program Files\Action Checkers
   Next, left-click on the ACTION CHECKERS executable "BVKT.exe",
   then with the cursor on the highlighted file, right-click and
   while holding the right mouse button, drag the file "BVKT.exe"
   into the other folder (the start menu folder). Next, release
   the right mouse button, and a small menu will pop up.
   Left-click on the "Create Shortcut Here" command in that menu.
   Next, rename the shortcut to "Action Checkers".

   Now, in order to run ACTION CHECKERS, simply left-click on the
   Start menu, left-click on Programs, then left-click on the
   "Action Checkers" icon.

-----------------------------------------------
INSTALLING ACTION CHECKERS from a 3.5" Diskette
-----------------------------------------------

1) Insert the 3.5" diskette into your floppy drive (the "A:"
   drive on most machines).

   There exists one folder on the floppy, titled "ACTION CHECKERS".

   Copy that folder into "C:\Program Files".

   ACTION CHECKERS is now installed on your computer.

2) If you would like to create a shortcut to ACTION CHECKERS in
   your Start Menu, follow the instructions in Step 3 above in the
   section "INSTALLING ACTION CHECKERS from a ZIP FILE OBTAINED
   from an INTERNET DOWNLOAD".

--------------------------
HOW to RUN ACTION CHECKERS
--------------------------

You can start ACTION CHECKERS using the shortcut in your Start menu
if you created one. To run ACTION CHECKERS from the Start menu,
left-click Start, then left-click Programs, then left-click
"Action Checkers".

You can also run ACTION CHECKERS by double-left-clicking directly
on the icon for the program's executable, 

	C:\Program Files\Action Checkers\BVKT.exe

---------------
TROUBLESHOOTING
---------------

Having trouble running ACTION CHECKERS?

Some machines which run older versions of Windows 95
may need an updated copy of the "Oleaut32.dll" file in
order for ACTION CHECKERS to work properly. A copy of this
file is included in the zip file which you downloaded.
If you need this newer file, a message box will
immediately appear when you try to run ACTION CHECKERS.
It will state that the file "Oleaut32.dll" cannot be
found (even if the older version of the DLL is on your
machine). In that case, move the version which comes
with ACTION CHECKERS into your "systems" folder, which on
most machines is "C:\Windows\System". You may want to
make a backup copy of your original version of the DLL
before moving the newer version into your systems folder.

NOTE: You should replace your original copy of "Oleaut32.dll"
with the version supplied in the ACTION CHECKERS zip file
only if the one in the zip file is NEWER than the one on
your machine. You can check the version number of a DLL
file by right-clicking on its icon to bring up the "properties"
menu, and selecting the "version" tab in the properties window.
Replace the DLL on your system only if the version number of
the one in the zip file is higher than the version number of
the original one.

------------
PACKING LIST
------------

Following installation, you should find the following files on
your hard drive.

Assuming that you installed ACTION CHECKERS in the folder
	C:\Program Files\Action Checkers,
you should have the following 11 files on your hard drive:

C:\Program Files\Action Checkers\BVKT.exe       (Executable File)
			        \BVKT.hlp       (Help File)
			        \README.txt     (this file)
				\Blast.wav      (sound file)
				\Electric.wav   (sound file)
				\Jump.wav       (sound file)
				\Rifle Shot.wav (sound file)
				\Siren.wav      (sound file)
				\Yay.wav        (sound file)
				\File_id.diz    (Program Description)
				\Oleaut32.dll   (Dynamic Link Library)

----------------
COPYRIGHT NOTICE
----------------

ACTION CHECKERS is protected by copyright law; it is not public
domain software.

------------------------------------
SHAREWARE VERSION of ACTION CHECKERS
------------------------------------

This is the shareware version of ACTION CHECKERS.

LeMonds Software is happy to grant you a limited license to
use the program for a period of up to 15 days in order to
evaluate the program before purchasing it. The shareware
version is a fully functional version of the program, in
which all features are operational. However, the shareware
version of ACTION CHECKERS will run on your computer for only 15
days following installation.

------------------------
REGISTER ACTION CHECKERS
------------------------

Your shareware copy of ACTION CHECKERS may be registered by
obtaining a registration code and entering it via the
Registration Information command in the Register menu.

Registration of ACTION CHECKERS affords you continued, unlimited
use of the program beyond the 15-day evaluation period on
the computer(s) on which you register the program. Please
submit payment for the registration fee for
ACTION CHECKERS to LeMonds Software (the cost for registering
the program is listed below). Upon receipt of the 
registration fee, LeMonds Software will promptly send you
a registration code which will enable ACTION CHECKERS to run
beyond the 15-day evaluation period on your computer(s).

To register ACTION CHECKERS, press the Enter Registration Code
button in the Registration Information menu, enter the 
registration code in the text field in the menu, the press 
Enter. Your copy of ACTION CHECKERS will then be registered and 
will work beyond the 15-day evaluation period.

-----------------------
SINGLE COMPUTER LICENSE
-----------------------

A single computer license grants the licensee the right to
install and use the program on a single computer. The
license may be transferred to another computer which is owned
by the licensee at any time as long as the ACTION CHECKERS program
is completely uninstalled from the computer on which it was 
previously licensed.

The cost of a single computer license is:

	$10.00	for a registration code via U.S. mail or e-mail
        or
	$13.00	for a 3.5" diskette + registration code sent
                via U.S. mail

Please note that if you already have the program (obtained via
an Internet download), you need only submit $10 for the
registration code. The diskette is useful if you do not have
Internet access, or if you would like to purchase the program
as a gift for someone.

-------------------------------
HOW to REGISTER ACTION CHECKERS
-------------------------------

Please send a check or money order for the appropriate
amount for the license(s) which you request to 
LeMonds Software at:

		LeMonds Software
		1 Fox Glen Ct.
		Clifton Park, NY  12065

Upon receipt of your remittance, LeMonds Software will send
a registration code for each license, and any diskettes
ordered.

-------------------------------
DISTRIBUTION of ACTION CHECKERS
-------------------------------

Please feel free to distribute your shareware copy of 
ACTION CHECKERS for the purpose of EVALUATION only, as long as you
have not modified any of the ACTION CHECKERS files in any way.

You may NOT give or sell your ACTION CHECKERS registration code
to any other party.

------------
LEGAL NOTICE
------------

LeMonds Software has gone to great lengths to design 
ACTION CHECKERS so that it will operate in a proper, safe, and
robust manner on the computer(s) on which it is intended to 
operate. However, LeMonds Software is not responsible for any 
damage which the ACTION CHECKERS program may do to any software 
or hardware on any computer system.

LeMonds Software disclaims all warranties relating to this 
software whether express or implied, including but not 
limited to any implied warranties of merchantability and 
fitness for a particular purpose, and all such warranties 
are expressly and specifically disclaimed.  Neither LeMonds
Software nor anyone else who has been involved in the 
creation, production, or delivery of this software shall 
be liable for any indirect, consequential, or incidental 
damages arising out of the use or inability to use such 
software even if the author has been advised of the 
possibility of such damages or claims.  In no event shall 
the author's liability for any damages ever exceed the 
price paid for the license to use the software, regardless 
of the form of claim, the person using the software bears 
all risks as to the quality and performance of the software.

Use of this product for any period of time constitutes
your acceptance of this agreement and subjects you to its
contents.

-------------------------------
HOW to CONTACT LeMONDS SOFTWARE
-------------------------------

Please feel free to send comments about ACTION CHECKERS, including
suggestions for improving the program, to:

	LeMonds Software
	1 Fox Glen Ct.
	Clifton Park, NY  12065

or send e-mail to:

	lemonds@worldnet.att.net

Thank you for choosing ACTION CHECKERS. We hope that you enjoy
playing the game.

Sincerely,

LeMonds Software

------------------------------------
OTHER PROGRAMS from LeMONDS SOFTWARE
------------------------------------

WORD BLAST -- A Hangman-like Program for Vocabulary
              and Spelling Enhancement

30-day Free Trial Period; $10 to Keep Program

Web Site:  http://home.att.net/~lemonds

WORD BLAST is an educational program designed to help 
children enhance their vocabulary and spelling skills in
a fun computer game setting (adults enjoy the game too).
In WORD BLAST, the player tries to guess a word 
letter-by-letter, as in the game of hangman. When a 
letter is correctly guessed, it is displayed in its 
position(s) in the word. Otherwise, a segment of the 
fuse leading to a bundle of dynamite "burns". If the 
word is completed before 10 incorrect guesses, then the 
player wins the game and receives an audio compliment. 
If not, then the dynamite "explodes". Children rarely 
lose a game since the definition of the word may be 
viewed before the fuse burns completely.

The game may be played either in the blast mode 
(described above), or in the vocabulary-builder mode, in 
which the definition of the word is displayed from the
outset. The latter playing mode makes the game easier
for young children, and makes WORD BLAST the ideal 
medium for helping to teach children the meanings of the
words on their weekly vocabulary lists from school.

New words and their definitions may be added in WORD 
BLAST via easy-to-use menus for the creation and editing 
of word lists. In addition, points are awarded when a 
word is correctly identified, and the names of the top 
ten scorers appear on a scoreboard with trophies.

With WORD BLAST, learning vocabulary and spelling is a 
"blast".

SYSTEM REQUIREMENTS for RUNNING WORD BLAST

	o) WINDOWS 95 Operating System
	o) 3 MB of free space on your hard drive.

-----------------------------------------------------------------

APP LAUNCHER -- Launch Applications, Files, Documents, etc.

30-day Free Trial Period; $10 to Keep Program

Web Site:  http://home.att.net/~lemonds

APP LAUNCHER provides a convenient way for organizing and starting up
your programs and for opening the folders and documents which you
frequently need to access. Your applications and documents can be
arranged in categories, each of which contains fifty buttons.
Each button can be used to launch a particular program or file, and
displays the icon of the application or file associated with it.
The result is a computer desktop which is free of clutter.
APP LAUNCHER is very well behaved: you can drag and drop files or
the shortcuts to them onto the buttons, but cannot accidentally drag
them off; they must be explicitly removed in a button deletion mode.
The program is easy to customize: provisions exist for moving and
copying buttons within or across categories, for changing the text
which is displayed with each button, and for changing the icons
which appear on the buttons. You may also use the program to fire up
your web browser, e-mail utility, or screen saver.

SYSTEM REQUIREMENTS for RUNNING WORD BLAST

	o) WINDOWS 95 Operating System
	o) 1 MB of free space on your hard drive.

-----------------------------------------------------------------

GOOD RIDDANCE -- A Convenient, Easy-to-Use, and Free File
                 Deletion Utility

Free (no registration fee)

Web Site:  http://home.att.net/~lemonds

GOOD RIDDANCE is a convenient, easy-to-use, and FREE file deletion
utility.

Use it to quickly clear the contents of various folders on your
hard drive, such as the caches which contain files downloaded
during Internet sessions (these files can number in the hundreds
or thousands and can occupy a lot of disk space). Deletion Sets
may be defined -- these are simply groups of folders which are to
be cleared. Select a deletion set, and clear its contents at the
press of a button (the folders are retained, the files in them are
deleted). Folders on your drives are displayed in a tree list, and
are color-coded red, green, or blue. Green folders can be cleared,
red ones cannot be (they may be changed to green in the future),
and blue folders cannot be cleared (they cannot be changed to green).
Two opportunities to abort the file deletion process when clearing
folders are given, and the files which will be deleted may be
displayed before the deletion occurs. The user may also specify a
list of file extensions , and files which use those extensions will
not be deleted during the folder clearing process.

GOOD RIDDANCE is a file deletion utility, and as such, there exists a
probability that mistakes can be made by the user which may result in
the unwanted deletion of files. However, various safeguards have been
implemented within the GOOD RIDDANCE program to minimize the
probability that this might happen.  Please read about these
safeguards in the program's help facility before using the program.

SYSTEM REQUIREMENTS for RUNNING GOOD RIDDANCE

	o) WINDOWS 95 Operating System
	o) 1 MB of free space on your hard drive.